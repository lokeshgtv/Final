export class ParentTaskModelModule { 
  ParentTaskId : number;
  ParentTaskName : string;
}